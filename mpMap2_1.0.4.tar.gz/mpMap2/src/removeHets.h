#ifndef REMOVE_HETS_HEADER_GUARD
#define REMOVE_HETS_HEADER_GUARD
#include <Rcpp.h>
SEXP removeHets(SEXP founders, SEXP finals, SEXP hetData);
#endif
