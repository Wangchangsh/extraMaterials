#ifndef GET_ALL_FUNNELS_INC_AIC_HEADER_GUARD
#define GET_ALL_FUNNELS_INC_AIC_HEADER_GUARD
#include <Rcpp.h>
SEXP getAllFunnelsIncAIC(SEXP geneticData, SEXP standardised);
#endif
