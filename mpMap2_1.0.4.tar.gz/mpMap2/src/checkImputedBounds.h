#ifndef CHECK_IMPUTED_BOUNDS_HEADER_GUARD
#define CHECK_IMPUTED_BOUNDS_HEADER_GUARD
#include <Rcpp.h>
SEXP checkImputedBounds(SEXP imputed);
#endif
