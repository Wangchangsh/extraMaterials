#ifndef CHECK_HETS_HEADER_GUARD
#define CHECK_HETS_HEADER_GUARD
#include <Rcpp.h>
RcppExport SEXP checkHets(SEXP hets);
#endif

