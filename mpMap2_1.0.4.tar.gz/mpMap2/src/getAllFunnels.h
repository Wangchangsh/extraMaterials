#ifndef GET_ALL_FUNNELS_HEADER_GUARD
#define GET_ALL_FUNNELS_HEADER_GUARD
#include <Rcpp.h>
SEXP getAllFunnels(SEXP geneticData, SEXP standardised);
#endif
