#ifndef COMBINE_GENOTYPES_HEADER_GUARD
#define COMBINE_GENOTYPES_HEADER_GUARD
#include <Rcpp.h>
RcppExport SEXP combineGenotypes(SEXP Rfinals, SEXP RhetData);
#endif

