#ifndef TEST_DISTORTION_HEADER_GUARD
#define TEST_DISTORTION_HEADER_GUARD
#include <Rcpp.h>
SEXP testDistortion(SEXP geneticData);
#endif
