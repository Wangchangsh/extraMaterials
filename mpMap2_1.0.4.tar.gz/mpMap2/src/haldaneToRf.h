#ifndef HALDANE_TO_RF_HEADER_GUARD
#define HALDANE_TO_RF_HEADER_GUARD
#include <vector>
void haldaneToRf(const std::vector<double>& inputs, std::vector<double>& outputs);
#endif
