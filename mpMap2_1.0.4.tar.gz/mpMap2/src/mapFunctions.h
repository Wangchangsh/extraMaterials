#ifndef MAP_FUNCTIONS_HEADER_GUARD
#define MAP_FUNCTIONS_HEADER_GUARD
double haldaneToRf(double x);
#endif
