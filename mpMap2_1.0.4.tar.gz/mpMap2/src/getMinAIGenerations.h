#ifndef GET_MIN_AI_GENERATIONS_HEADER_GUARD
#define GET_MIN_AI_GENERATIONS_HEADER_GUARD
#include <vector>
int getMinAIGenerations(const std::vector<int>* intercrossingGenerations);
#endif

