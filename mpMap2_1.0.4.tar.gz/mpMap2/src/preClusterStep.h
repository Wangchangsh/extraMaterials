#ifndef PRE_CLUSTER_STEP_HEADER_GUARD
#define PRE_CLUSTER_STEP_HEADER_GUARD
#include <Rcpp.h>
SEXP preClusterStep(SEXP mpcrossRF);
#endif
