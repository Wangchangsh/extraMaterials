#ifndef COMBINE_RF_DISJOINT_HEADER_GUARD
#define COMBINE_RF_DISJOINT_HEADER_GUARD
#include <Rcpp.h>
RcppExport SEXP combineRFDisjoint(SEXP rf1, SEXP rf2);
#endif
