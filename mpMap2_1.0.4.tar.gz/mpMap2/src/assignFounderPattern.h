#ifndef ASSIGN_FOUNDER_PATTERN_HEADER_GUARD
#define ASSIGN_FOUNDER_PATTERN_HEADER_GUARD
#include <Rcpp.h>
RcppExport SEXP assignFounderPattern(SEXP geneticData, SEXP founderMatrix);
#endif
