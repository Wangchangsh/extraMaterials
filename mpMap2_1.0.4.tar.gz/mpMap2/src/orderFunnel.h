#ifndef ORDER_FUNNEL_HEADER_GUARD
#define ORDER_FUNNEL_HEADER_GUARD
void orderFunnel(int* funnel, int nFounders);
#endif

