#ifndef MPMAP2_OPENMP_HEADER_GUARD
#define MPMAP2_OPENMP_HEADER_GUARD
#include <Rcpp.h>
SEXP mpMap2_omp_set_num_threads(SEXP num);
SEXP mpMap2_omp_get_num_threads();
#endif


