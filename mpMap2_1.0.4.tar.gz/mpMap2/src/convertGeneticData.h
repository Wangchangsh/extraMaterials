#ifndef CONVERT_GENETIC_DATA_HEADER_GUARD
#define CONVERT_GENETIC_DATA_HEADER_GUARD
#include <Rcpp.h>
void convertGeneticData(Rcpp::S4 obj);
#endif

