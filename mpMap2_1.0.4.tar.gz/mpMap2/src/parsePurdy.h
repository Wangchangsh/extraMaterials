#ifndef PARSE_PURDY_HEADER_GUARD
#define PARSE_PURDY_HEADER_GUARD
#include <Rcpp.h>
SEXP parsePurdy(SEXP names, SEXP format);
#endif
