#include "compressedProbabilities.h"	
const int compressedProbabilities<2, true>::nDifferentProbs;	
const int compressedProbabilities<2, false>::nDifferentProbs;	
const int compressedProbabilities<4, true>::nDifferentProbs;	
const int compressedProbabilities<4, false>::nDifferentProbs;	
const int compressedProbabilities<8, true>::nDifferentProbs;	
const int compressedProbabilities<8, false>::nDifferentProbs;	
const int compressedProbabilities<16, true>::nDifferentProbs;	
const int compressedProbabilities<16, false>::nDifferentProbs;
