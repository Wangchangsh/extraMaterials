#pragma once
#include "Rcpp.h"
//Copied from the methods package
SEXP identC(SEXP e1, SEXP e2);
