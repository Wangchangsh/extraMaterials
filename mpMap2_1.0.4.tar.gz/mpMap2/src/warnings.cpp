#include "warnings.h"
std::string hetWarning = "Input data had heterozygotes but was analysed assuming infinite selfing. All heterozygotes were ignored.";
