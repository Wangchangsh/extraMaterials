#ifndef GENERATE_DESIGN_MATRIX_HEADER_GUARD
#define GENERATE_DESIGN_MATRIX_HEADER_GUARD
#include <Rcpp.h>
SEXP generateDesignMatrix(SEXP n, SEXP maxOffset);
#endif
