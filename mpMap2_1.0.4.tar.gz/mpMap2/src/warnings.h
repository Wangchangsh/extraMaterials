#ifndef WARNINGS_HEADER_GUARD
#define WARNINGS_HEADER_GUARD
#include <string>
//Warning for the case where there are hets, but we're assuming infinite selfing
extern std::string hetWarning;
#endif
