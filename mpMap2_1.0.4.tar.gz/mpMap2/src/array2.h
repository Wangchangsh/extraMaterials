#ifndef ARRAY_2_HEADER_GUARD
#define ARRAY_2_HEADER_GUARD
template<int n> struct array2
{
public:
	array2()
	{}
	double values[n][n];
};
#endif
