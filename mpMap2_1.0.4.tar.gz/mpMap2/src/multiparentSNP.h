#ifndef MULTIPARENT_SNP_HEADER_GUARD
#define MULTIPARENT_SNP_HEADER_GUARD
#include <Rcpp.h>
SEXP multiparentSNPRemoveHets(SEXP object);
SEXP multiparentSNPKeepHets(SEXP object);
#endif
