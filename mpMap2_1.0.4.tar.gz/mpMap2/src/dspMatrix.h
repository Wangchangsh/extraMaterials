#ifndef DSP_MATRIX_HEADER_GUARD
#define DSP_MATRIX_HEADER_GUARD
#include <Rcpp.h>
SEXP assignDspMatrixFromEstimateRF(SEXP destination, SEXP rowIndices, SEXP columnIndices, SEXP source);
#endif
