.identC <- function (c1 = NULL, c2 = NULL)
{
	.Call("identC", c1, c2, PACKAGE="mpMap2")
}
